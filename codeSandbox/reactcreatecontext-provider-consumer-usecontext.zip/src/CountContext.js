import React from "react";

export const CountContext = React.createContext();
